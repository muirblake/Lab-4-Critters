/* CRITTERS <MyClass.java>
 * EE422C Project 4 submission by
 * Replace <...> with your actual data.
 * Blake Muir
 * Bmm2897
 * <Student1 5-digit Unique No.>
 * James Tsao
 * jt28593
 * <Student2 5-digit Unique No.>
 * Slip days used: 1
 * Fall 2015
 */

package project4;
import java.util.Scanner;

import java.util.Scanner;

public class Main {

	static Scanner kb = new Scanner(System.in);
	static UIText tui = new UIText(kb);
	public static void main(String[] args) throws Exception {
		while(true){
			tui.nextcmd();
		}
	}
}
